<a name="2.0.2"></a>
## [2.0.2](https://github.com/akveo/ngx-admin/compare/v2.0.1...v2.0.2) (2018-01-09)


### Features

* **dashboard:** default card with a message ([f8d94e7](https://github.com/akveo/ngx-admin/commit/f8d94e7))
* **dependencies:** update dependencies, angular 5+, nebular rc.4 ([#1477](https://github.com/akveo/ngx-admin/issues/1477)) ([51ee632](https://github.com/akveo/ngx-admin/commit/51ee632))



<a name="2.0.1"></a>
## [2.0.1](https://github.com/akveo/ngx-admin/compare/v2.0.0...v2.0.1) (2017-10-26)


Nebular changelog is available [here](https://github.com/akveo/nebular/blob/master/CHANGELOG.md#200-rc3-2017-10-26) for more details. 

### Features

* **bootstrap:** update bootstrap to beta.2, nebular to rc.3 ([b525213](https://github.com/akveo/ngx-admin/commit/b525213))
* **compodoc:** add compodoc documentation generator ([#1327](https://github.com/akveo/ngx-admin/issues/1327)) ([eebbc12](https://github.com/akveo/ngx-admin/commit/eebbc12))
* **loader:** add loading progress indicator ([#1319](https://github.com/akveo/ngx-admin/issues/1319)) ([f479715](https://github.com/akveo/ngx-admin/commit/f479715))



